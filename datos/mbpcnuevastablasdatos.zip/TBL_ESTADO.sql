Insert into TBL_ESTADO
   (ID, NOMBRE)
 Values
   (1, 'Solido');
Insert into TBL_ESTADO
   (ID, NOMBRE)
 Values
   (2, 'Liquido');
Insert into TBL_ESTADO
   (ID, NOMBRE)
 Values
   (3, 'Gaseoso');
COMMIT;
