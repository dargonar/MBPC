
Insert into TBL_TIPO_CARGAS_PELIGROSAS
   (ID, NOMBRE)
 Values
   (0, 'Explosivo');
Insert into TBL_TIPO_CARGAS_PELIGROSAS
   (ID, NOMBRE)
 Values
   (1, 'Contaminante');
Insert into TBL_TIPO_CARGAS_PELIGROSAS
   (ID, NOMBRE)
 Values
   (2, 'Radioactivo');
COMMIT;
