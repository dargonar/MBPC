
Insert into tbl_muelles
   (ID, PUERTO_ID, INSTA_PORT, TIPO_NAV_ID, TIPO_CARG_ID, LATITUD, LONGITUD, DIRECCION, INT, MAIL, TE, FAX, DESCRIPCION)
 Values
   (1, 5017, 119, 0, 563, 
    '33�39''00"S', '59�15''00"W', 'ZONA PORTUARIA', '2914', 'zonaport@gmail.com', 
    '47445326', '47', 'MUELLE - IBICUY -SAN BENITO');
COMMIT;
