Insert into TBL_BQ_CODPROV
   (PROV, CODIGO)
 Values
   ('NO ESPECIF', '0');
Insert into TBL_BQ_CODPROV
   (PROV, CODIGO)
 Values
   ('BSAS', 'B');
Insert into TBL_BQ_CODPROV
   (PROV, CODIGO)
 Values
   ('CAP.FED.', 'C');
Insert into TBL_BQ_CODPROV
   (PROV, CODIGO)
 Values
   ('CATAMARCA', 'K');
Insert into TBL_BQ_CODPROV
   (PROV, CODIGO)
 Values
   ('CHACO', 'H');
Insert into TBL_BQ_CODPROV
   (PROV, CODIGO)
 Values
   ('CHUBUT', 'U');
Insert into TBL_BQ_CODPROV
   (PROV, CODIGO)
 Values
   ('CORDOBA', 'X');
Insert into TBL_BQ_CODPROV
   (PROV, CODIGO)
 Values
   ('CORRIENTES', 'W');
Insert into TBL_BQ_CODPROV
   (PROV, CODIGO)
 Values
   ('ENTRE RIOS', 'E');
Insert into TBL_BQ_CODPROV
   (PROV, CODIGO)
 Values
   ('FORMOSA', 'P');
Insert into TBL_BQ_CODPROV
   (PROV, CODIGO)
 Values
   ('JUJUY', 'Y');
Insert into TBL_BQ_CODPROV
   (PROV, CODIGO)
 Values
   ('LA PAMPA', 'L');
Insert into TBL_BQ_CODPROV
   (PROV, CODIGO)
 Values
   ('LA RIOJA', 'F');
Insert into TBL_BQ_CODPROV
   (PROV, CODIGO)
 Values
   ('MENDOZA', 'M');
Insert into TBL_BQ_CODPROV
   (PROV, CODIGO)
 Values
   ('MISIONES', 'N');
Insert into TBL_BQ_CODPROV
   (PROV, CODIGO)
 Values
   ('NEUQUEN', 'Q');
Insert into TBL_BQ_CODPROV
   (PROV, CODIGO)
 Values
   ('RIO NEGRO', 'R');
Insert into TBL_BQ_CODPROV
   (PROV, CODIGO)
 Values
   ('SALTA', 'A');
Insert into TBL_BQ_CODPROV
   (PROV, CODIGO)
 Values
   ('SAN JUAN', 'J');
Insert into TBL_BQ_CODPROV
   (PROV, CODIGO)
 Values
   ('SAN LUIS', 'D');
Insert into TBL_BQ_CODPROV
   (PROV, CODIGO)
 Values
   ('SANTA CRUZ', 'Z');
Insert into TBL_BQ_CODPROV
   (PROV, CODIGO)
 Values
   ('SANTA FE', 'S');
Insert into TBL_BQ_CODPROV
   (PROV, CODIGO)
 Values
   ('S.D.ESTERO', 'G');
Insert into TBL_BQ_CODPROV
   (PROV, CODIGO)
 Values
   ('T. DEL FUEGO', 'V');
Insert into TBL_BQ_CODPROV
   (PROV, CODIGO)
 Values
   ('TUCUMAN', 'T');
COMMIT;
