
Insert into TBL_CLASIFICACION
   (ID, NOMBRE)
 Values
   (1, 'AGRICULTURA');
Insert into TBL_CLASIFICACION
   (ID, NOMBRE)
 Values
   (2, 'CARGA GENERAL EN UNIDADES');
Insert into TBL_CLASIFICACION
   (ID, NOMBRE)
 Values
   (3, 'CARGA GENERAL EN TONELADAS');
Insert into TBL_CLASIFICACION
   (ID, NOMBRE)
 Values
   (4, 'COMBUSTIBLES');
Insert into TBL_CLASIFICACION
   (ID, NOMBRE)
 Values
   (5, 'METALES FERROSOS Y NO FERROSOS');
Insert into TBL_CLASIFICACION
   (ID, NOMBRE)
 Values
   (6, 'FORESTALES');
Insert into TBL_CLASIFICACION
   (ID, NOMBRE)
 Values
   (7, 'GANADERIA');
Insert into TBL_CLASIFICACION
   (ID, NOMBRE)
 Values
   (8, 'CONTENEDORES');
Insert into TBL_CLASIFICACION
   (ID, NOMBRE)
 Values
   (9, 'SIN CARGA');
Insert into TBL_CLASIFICACION
   (ID, NOMBRE)
 Values
   (10, 'ALIMENTOS');
Insert into TBL_CLASIFICACION
   (ID, NOMBRE)
 Values
   (11, 'MINERIA');
Insert into TBL_CLASIFICACION
   (ID, NOMBRE)
 Values
   (12, 'PRACTICAJES');
Insert into TBL_CLASIFICACION
   (ID, NOMBRE)
 Values
   (13, 'PASAJEROS');
Insert into TBL_CLASIFICACION
   (ID, NOMBRE)
 Values
   (14, 'QUIMICOS, FERTILIZANTES Y DROGAS');
Insert into TBL_CLASIFICACION
   (ID, NOMBRE)
 Values
   (15, 'ARMAS Y EXPLOSIVOS');
Insert into TBL_CLASIFICACION
   (ID, NOMBRE)
 Values
   (16, 'TRENES');
Insert into TBL_CLASIFICACION
   (ID, NOMBRE)
 Values
   (17, 'AUTOMOTORES');
Insert into TBL_CLASIFICACION
   (ID, NOMBRE)
 Values
   (18, 'SIN CLASIFICAR');
Insert into TBL_CLASIFICACION
   (ID, NOMBRE)
 Values
   (19, 'MERCANCIAS PELIGROSAS');
Insert into TBL_CLASIFICACION
   (ID, NOMBRE)
 Values
   (20, 'Pasajeros');
COMMIT;
