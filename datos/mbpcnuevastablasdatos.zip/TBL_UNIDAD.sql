
Insert into TBL_UNIDAD
   (ID, NOMBRE)
 Values
   (1, 'TN');
Insert into TBL_UNIDAD
   (ID, NOMBRE)
 Values
   (2, 'M3');
Insert into TBL_UNIDAD
   (ID, NOMBRE)
 Values
   (3, 'Unidades');
COMMIT;
